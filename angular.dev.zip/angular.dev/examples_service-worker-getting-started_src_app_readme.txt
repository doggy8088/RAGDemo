# Instructions for Angular Universal Example Download

This is the downloaded sample code for the [Angular Universal (Standalone) guide](https://angular.dev/guide/ssr).

## Install and Run

1. `npm install` to install the `node_module` packages
2. `npm run dev:ssr` to launch the server and application
3. Launch the browser to `http://localhost:4200`
