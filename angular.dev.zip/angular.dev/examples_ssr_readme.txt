# Instructions for Angular SSR Example Download

This is the downloaded sample code for the [Angular SSR (Standalone) guide](https://angular.io/guide/ssr).

## Install and Run

1. `npm install` to install the `node_module` packages
2. `ng serve` to launch the dev-server
3. Launch the browser to `http://localhost:4200`
