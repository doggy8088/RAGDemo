
git clone https://github.com/angular/angular.git -b main --no-checkout --depth=1
cd angular

git sparse-checkout init --cone

echo "/adev/src/content/**/*.md" > .git/info/sparse-checkout

git checkout

cd adev/src/content/

Get-ChildItem -Recurse -Filter *.md | Rename-Item -NewName { $_.Name -replace '\.md$', '.txt' }

Get-ChildItem -Recurse -Filter *.txt | ForEach-Object {
    $newName = ($_.DirectoryName -replace [regex]::Escape((Get-Location).Path), '') -replace '\\', '_'
    $newName = $newName.TrimStart('_') + "_" + $_.Name
    Move-Item $_.FullName -Destination (Join-Path -Path (Get-Location) -ChildPath $newName)
}

Get-ChildItem -Directory -Recurse | Remove-Item -Recurse -Force
